PROCESSOR 16F877
;	Clock = XT 4MHz, standard fuse settings
	__CONFIG 0x3731	; 00011011100110001

;	LABEL EQUATES	;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

	INCLUDE "P16F877A.INC"
	
	

        ORG     0x0000
        GOTO    START
		
		INCLUDE "LCDIS.INC"
START:

		BANKSEL PORTB
		CLRF PORTB
		CLRF PORTD
		
		BANKSEL TRISD
		CLRF TRISD
		CLRF TRISB
		
		CALL inid
		BSF Select, RS
		
		MOVLW 'H'
		CALL send
		
		MOVLW 'E'
		CALL send
		
		MOVLW 'L'
		CALL send
		
		MOVLW 'L'
		CALL send
		
		MOVLW 'O'
		CALL send
		
	


		
LOOP:
		GOTO	LOOP
		END
		
		
